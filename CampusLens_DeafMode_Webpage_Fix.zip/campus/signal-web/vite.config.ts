import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': { target: 'http://127.0.0.1:3001' },
      '/ws': { target: 'ws://127.0.0.1:3001', ws: true },
      '/recognition': {
        target: 'http://127.0.0.1:8002',
        changeOrigin: true,
        rewrite: path => path.replace(/^\/recognition/, ''),
      },
    },
  },
});
